#include "1.h"
#include "2.h"
#include "3.h"
#include "4.h"
#include "5.h"
#include "6.h"      //gauge
#include "7.h" // eq
#include "8.h" // turbo
#include "9.h"
#include "10.h"
#include "11.h" //cry
#include "12.h" //big meteo rain
#include "13.h"
#include "14.h"
#include "15.h" //eye beam
#include "16.h"
#include "17.h" //virus
#include "18.h"
#include "19.h"
#include "20.h"// police
#include "21.h"
#include "22.h"
#include "23.h"
#include "24.h"
#include "25.h"  //upside down
#include "26.h"  //dasai
#include "27.h"  //glowing eyes
#include "28.h"  //smile look up
#include "29.h" //sakura
#include "30.h" //hiding
#include "31.h" //new intro
#include "32.h" //new dasai
#include "33.h" //new police
#include "34.h" //new eye beam
#include "35.h" //new virus
#include "36.h" //new cry
#include "37.h"  //new glowing eyes
#include "38.h" //initial d
#include "39.h" //miku
#include "40.h" //new eq
#include "41.h" //new star rain
#include "42.h" //new initial d
#include "intro.h"
#include "jojos.h"
